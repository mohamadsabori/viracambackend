package com.xebialab.assignment.service;

import com.xebialab.assignment.DTO.*;
import com.xebialab.assignment.domain.Game;
import com.xebialab.assignment.domain.Player;
import com.xebialab.assignment.domain.Point;
import com.xebialab.assignment.domain.Spaceship;
import com.xebialab.assignment.enums.*;
import com.xebialab.assignment.repository.GameRepository;
import com.xebialab.assignment.repository.PlayerRepository;
import com.xebialab.assignment.repository.PointRepository;
import com.xebialab.assignment.repository.SpaceshipRepository;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.*;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SalvoServiceTests {

    @Autowired
    private SalvoServiceImpl salvoService;
    @Autowired
    private IProtocolService protocolService;

    @Autowired
    private GameRepository gameRepository;

    @Test
    public void shouldReceiveSalvo(){
        PlayerDTO opponent = new PlayerDTO("opponent", "opponentId");
        GameDTO gameDTO = protocolService.createNewGame(opponent);
        Game game = gameRepository.findOneByGameId(gameDTO.getGameId());
        int row = game.getFirstPlayer().getSpaceships().get(0).getPoints().get(0).getRow();
        int col = game.getFirstPlayer().getSpaceships().get(0).getPoints().get(0).getCol();

        List<PointDTO> points = new ArrayList<>();
        points.add(new PointDTO(row + "x"+ col, ""));
        SalvoResultDTO salvoResult = salvoService.receiveSalvo(points, game.getGameId(), false);
        Assert.assertEquals(salvoResult.getFireInfoes().get(0).getStatus(),"hit");
    }

    @Test
    public void shouldShootSalvo(){
        PlayerDTO opponent = new PlayerDTO("opponent", "opponentId");
        GameDTO gameDTO = protocolService.createNewGame(opponent);
        Game game = gameRepository.findOneByGameId(gameDTO.getGameId());
        int row = game.getSecondPlayer().getSpaceships().get(0).getPoints().get(0).getRow();
        int col = game.getSecondPlayer().getSpaceships().get(0).getPoints().get(0).getCol();

        List<PointDTO> points = new ArrayList<>();
        points.add(new PointDTO(row + "x"+ col, ""));
        SalvoResultDTO salvoResult = salvoService.receiveSalvo(points, game.getGameId(), true);
        Assert.assertEquals(salvoResult.getFireInfoes().get(0).getStatus(),"hit");
    }
}
