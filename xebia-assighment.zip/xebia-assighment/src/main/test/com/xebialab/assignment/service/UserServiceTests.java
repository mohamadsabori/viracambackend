package com.xebialab.assignment.service;

import com.xebialab.assignment.DTO.PlayerDTO;
import org.hamcrest.collection.IsEmptyCollection;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import static org.hamcrest.CoreMatchers.*;


import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasSize;

@RunWith(SpringRunner.class)
@SpringBootTest()
public class UserServiceTests {
    @Autowired
    IPlayerService playerService;

    @Test
    public void should_create_with_all_spaceships(){
        PlayerDTO self = new PlayerDTO("Spaceship", "xl-spaceship-player");
        playerService.createRandoBoardForUser(self);
        assertThat(self.getSpaceships(),not(IsEmptyCollection.empty()));
        assertThat(self.getSpaceships(), hasSize(5));

    }

}
