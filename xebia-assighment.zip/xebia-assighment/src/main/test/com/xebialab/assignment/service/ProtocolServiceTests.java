package com.xebialab.assignment.service;

import com.xebialab.assignment.DTO.GameDTO;
import com.xebialab.assignment.DTO.PlayerDTO;
import com.xebialab.assignment.domain.Game;
import com.xebialab.assignment.domain.Player;
import com.xebialab.assignment.repository.GameRepository;
import com.xebialab.assignment.repository.PlayerRepository;
import com.xebialab.assignment.repository.PointRepository;
import com.xebialab.assignment.repository.SpaceshipRepository;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;
import java.util.Random;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ProtocolServiceTests {

    @Mock
    PlayerRepository playerRepository;
    @Mock GameRepository gameRepository;
    @Mock PointRepository pointRepository;
    @Mock SpaceshipRepository spaceshipRepository;
    @Mock IPlayerService playerService;
    Random random = new Random();

    private ProtocolServiceImpl protocolService;

    @Before
    public void init() {

        protocolService = new ProtocolServiceImpl(random, playerRepository, gameRepository, pointRepository, spaceshipRepository, playerService);
    }

    @Test
    public void should_not_create_new_game() {

        PlayerDTO self = new PlayerDTO("Spaceship", "xl-spaceship-player");
        Player selfEntity = new Player();
        selfEntity.setUserId("Spaceship");
        selfEntity.setFullName("xl-spaceship-player");
        PlayerDTO opponent = new PlayerDTO("XebiaLabs", "xebialabs");
        Player opoonentEntity = new Player();
        opponent.setUserId("XebiaLabs");
        opponent.setFullName("xebialabs");
        when(playerRepository.save(selfEntity)).thenReturn(selfEntity);
        when(playerRepository.save(opoonentEntity)).thenReturn(opoonentEntity);
        Game game = new Game().builder()
                .firstPlayer(selfEntity)
                .secondPlayer(opoonentEntity).created(new Date())
                .starterPlayer(new Random().nextBoolean() ? selfEntity : opoonentEntity)
                .build();
        when(gameRepository.save(any(Game.class))).thenReturn(game);

        GameDTO gameDTO = protocolService.createNewGame(opponent);
        Assert.assertEquals(gameDTO.getFirstPlayer().getUserId(), self.getUserId());
        Assert.assertNotEquals(gameDTO.getSecondPlayer().getFullName(), self.getFullName());
    }

    @Test
    public void should_create_new_game() {

        PlayerDTO self = new PlayerDTO("Spaceship", "xl-spaceship-player");
        Player selfEntity = new Player();
        selfEntity.setUserId("Spaceship");
        selfEntity.setFullName("xl-spaceship-player");
        PlayerDTO opponent = new PlayerDTO("XebiaLabs", "xebialabs");
        Player opoonentEntity = new Player();
        opponent.setUserId("XebiaLabs");
        opponent.setFullName("xebialabs");
        when(playerRepository.save(selfEntity)).thenReturn(selfEntity);
        when(playerRepository.save(opoonentEntity)).thenReturn(opoonentEntity);
        Game game = new Game().builder()
                .firstPlayer(selfEntity)
                .secondPlayer(opoonentEntity).created(new Date())
                .starterPlayer(new Random().nextBoolean() ? selfEntity : opoonentEntity)
                .build();
        when(gameRepository.save(any(Game.class))).thenReturn(game);

        GameDTO gameDTO = protocolService.createNewGame(opponent);
        Assert.assertEquals(gameDTO.getFirstPlayer().getUserId(), self.getUserId());
        Assert.assertEquals(gameDTO.getSecondPlayer().getFullName(), opponent.getFullName());
    }
}
