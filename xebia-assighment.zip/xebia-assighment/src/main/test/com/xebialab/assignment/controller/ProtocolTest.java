package com.xebialab.assignment.controller;


import com.xebialab.assignment.DTO.PointDTO;
import com.xebialab.assignment.domain.Game;
import com.xebialab.assignment.domain.Player;
import com.xebialab.assignment.repository.GameRepository;
import com.xebialab.assignment.service.IProtocolService;
import io.restassured.RestAssured;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class ProtocolTest {

    @LocalServerPort
    private int port;

    @Autowired
    private GameRepository gameRepository;

    @Before
    public void setup() {

        RestAssured.port = port;
    }

    @Test
    public void should_start_game() {

        Player player = new Player();
        player.setUserId("xebialabs-1");
        player.setFullName("Xebialabs Opponent");

        given()
                .contentType("application/json")
                .body(player)
                .when()
                .post("/xl-spaceship/protocol/game/new")
                .then()
                .assertThat()
                .body("gameId", equalTo("match-0"))
                .body("firstPlayer.userId", equalTo("xl-spaceship-player"))
                .body("secondPlayer.userId", equalTo("xebialabs-1"));
    }

    @Test
    public void should_get_game_status_by_game_id() {

        Player player = new Player();
        player.setUserId("xebialabs-1");
        player.setFullName("Xebialabs Opponent");

        String gameId = given()
                .contentType("application/json")
                .body(player)
                .when()
                .post("/xl-spaceship/protocol/game/new")
                .then()
                .extract()
                .as(Game.class).getGameId();
        given()
                .when()
                .get("/xl-spaceship/user/game/" + gameId)
                .then()
                .assertThat()
                .body("firstPlayer.userId", equalTo("player"))
                .body("firstPlayer.fullName", equalTo("Assessment Player"))
                .body("secondPlayer.userId", equalTo("xebialabs-1"))
                .body("secondPlayer.fullName", equalTo("Xebialabs Opponent"))
                .body("firstPlayer.board", hasSize(16))
                .body("secondPlayer.board", hasSize(16));
    }

    @Test
    public void should_fire() {

        Player player = new Player();
        player.setUserId("xebialabs-1");
        player.setFullName("Xebialabs Opponent");

        given()
                .contentType("application/json")
                .body(player)
                .when()
                .post("/xl-spaceship/protocol/game/new")
                .then()
                .assertThat()
                .body("gameId", equalTo("match-0"))
                .body("firstPlayer.userId", equalTo("xl-spaceship-player"))
                .body("secondPlayer.userId", equalTo("xebialabs-1"));

        Game game = gameRepository.findOneByGameId("match-0");
        int row = game.getFirstPlayer().getSpaceships().get(0).getPoints().get(0).getRow();
        int col = game.getFirstPlayer().getSpaceships().get(0).getPoints().get(0).getCol();
        List<PointDTO> points = new ArrayList<>();
        points.add(new PointDTO(row + "x"+ col, ""));

        Map<String, Object> expected = new HashMap<>();
        expected.put("point", row + "x"+ col);
        expected.put("status", "hit");

        given()
                .contentType("application/json")
                .body(points)
                .when()
                .post("/xl-spaceship/protocol/game/" + "match-0")
                .then()
                .assertThat()
                .body("fireInfoes", hasItems(expected));
    }
    @Test
    public void should_receive_salvo() {

        Player player = new Player();
        player.setUserId("xebialabs-1");
        player.setFullName("Xebialabs Opponent");

        given()
                .contentType("application/json")
                .body(player)
                .when()
                .post("/xl-spaceship/protocol/game/new")
                .then()
                .assertThat()
                .body("gameId", equalTo("match-0"))
                .body("firstPlayer.userId", equalTo("xl-spaceship-player"))
                .body("secondPlayer.userId", equalTo("xebialabs-1"));

        Game game = gameRepository.findOneByGameId("match-0");
        int row = game.getSecondPlayer().getSpaceships().get(0).getPoints().get(0).getRow();
        int col = game.getSecondPlayer().getSpaceships().get(0).getPoints().get(0).getCol();
        List<PointDTO> points = new ArrayList<>();
        points.add(new PointDTO(row + "x"+ col, ""));

        Map<String, Object> expected = new HashMap<>();
        expected.put("point", row + "x"+ col);
        expected.put("status", "hit");

        given()
                .contentType("application/json")
                .body(points)
                .when()
                .post("/xl-spaceship/user/game/match-0/fire")
                .then()
                .assertThat()
                .body("fireInfoes", hasItems(expected));
    }
}
