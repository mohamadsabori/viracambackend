package com.xebialab.assignment.controller;

public class UserTest {
}
