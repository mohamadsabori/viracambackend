var gameModule = angular.module('gameModule', []);


gameModule.controller('newGameController', ['$rootScope', '$scope', '$http', '$location',
    function (rootScope, scope, http, location) {

        rootScope.gameId = null;
        scope.newGameData = null;

        scope.newGameOptions = {
            availablePieces: [
                {name: 'X'},
                {name: 'O'}
            ],
            selectedPiece: {name: 'O'},
            availableGameTypes: [
                {name: 'COMPETITION'},
                {name: 'COMPUTER'}
            ],
            selectedBoardDimension: {name: 'COMPUTER'}
        };

        scope.createNewGame = function () {

            var data = {'fullName': 'XebiaLabs Opponent', 'userId': "xebialabs-1"};
            var params = JSON.stringify(data);
            http.post("/xl-spaceship/protocol/game/new", data, {
                headers: {
                    'Content-Type': 'application/json; charset=UTF-8'
                }
            }).success(function (responseData, status, headers, config) {
                rootScope.game = responseData;
                if (rootScope.game.starterPlayer.userId == data.userId) {
                    isMyTurn = false;
                    rootScope.fireButtonTitle = 'Opponent Fire!';
                } else {
                    isMyTurn = true;
                    rootScope.fireButtonTitle = 'Fire!';
                }
                rootScope.salvoPoints = [{point: "", status: ""} , {point: "", status: ""} , {point: "", status: ""}, {point: "", status: ""}, {point: "", status: ""}];
            }).error(function (data, status, headers, config) {
                location.path('/player/panel');
            });
        }

        function extracted(responseData) {
            rootScope.salvoPoints = [{point: "", status: ""}, {point: "", status: ""}, {
                point: "",
                status: ""
            }, {point: "", status: ""}, {point: "", status: ""}];
            rootScope.game = responseData.gameDTO;
            rootScope.salvoPoints = responseData.fireInfoes;
            if (!isMyTurn) {
                rootScope.fireButtonTitle = 'Opponent Fire!';
                isMyTurn = true;
            } else {
                isMyTurn = false;
                rootScope.fireButtonTitle = 'Fire!';
            }
        }

        scope.fire = function () {
            if(!validateSalvo()) return;
            var data = rootScope.salvoPoints;
            if (scope.isMyTurn) {
                http.post("/xl-spaceship/user/" + rootScope.game.gameId + "/game/", data, {
                    headers: {
                        'Content-Type': 'application/json; charset=UTF-8'
                    }
                }).success(function (responseData, status, headers, config) {
                    extracted(responseData);

                });

            } else {
                http.post("/xl-spaceship/protocol/game/" + rootScope.game.gameId, data, {
                    headers: {
                        'Content-Type': 'application/json; charset=UTF-8'
                    }
                }).success(function (responseData, status, headers, config) {
                    console.log(responseData);
                    extracted(responseData);
                });
            }
        }

        function validateSalvo() {
            rootScope.salvoPoints.forEach(function (value) {
                if (value.point == "") {
                    value.message = "Please fill in the shots!";
                    return false;
                }

                if (!value.point.match("[0-9a-fA-F][xX][0-9a-fA-F]")) {
                    value.message = "Incorrect Shot Format!\nExample: AxF, 6x9";
                    return false;
                } else{
                    value.message = "";
                }
            });
            return true;
        }
    }
]);



