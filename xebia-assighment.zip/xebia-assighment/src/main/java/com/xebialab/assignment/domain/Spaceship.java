package com.xebialab.assignment.domain;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
public class Spaceship {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id", nullable = false)
    int id;
    @Column(name = "name", nullable = false)
    private String name;
    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name="spaceship_id")
    private List<Point> points = new ArrayList<>();
    @Column(name = "status", nullable = false)
    private String status;

    public Spaceship(String name, List<Point> points, String status) {
        this.name = name;
        this.points = points;
        this.status = status;
    }

    public Spaceship() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Point> getPoints() {
        return points;
    }

    public void setPoints(List<Point> points) {
        this.points = points;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
