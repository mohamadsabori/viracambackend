package com.xebialab.assignment.enums;

import com.xebialab.assignment.DTO.SpaceshipDTO;

public class AClass extends SpaceshipDTO {
    public AClass() {
        super("A-CLass");
        setShape(".*.\n*.*\n***\n*.*");
    }
}
