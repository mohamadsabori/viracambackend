package com.xebialab.assignment.controller;

import com.xebialab.assignment.DTO.*;
import com.xebialab.assignment.domain.Game;
import com.xebialab.assignment.domain.Player;
import com.xebialab.assignment.service.IProtocolService;
import com.xebialab.assignment.service.ISalvoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * Protocol RestAPI Controller to handle API calls related to spaceships
 * Spaceships communicate with each other through this End-Point. The controller
 * uses service classes as its dependencies to delegate the required business to them.
 * Therefore, no further business is handled inside the handler functions.
 */
@RestController()
@RequestMapping("/protocol")
public class ProtocolController {

    IProtocolService gameService;
    ISalvoService salvoService;

    @Autowired
    public ProtocolController(IProtocolService gameService,ISalvoService salvoService) {
        this.gameService = gameService;
        this.salvoService = salvoService;
    }

    /**
     * The end-point to create a new game with the given opponent.
     * @param player The opponent to play with
     * @return The game initialized with specified players
     */
    @PostMapping("/game/new")
    public ResponseEntity<GameDTO> createNewGameSimulation(@RequestBody PlayerDTO player) {
        GameDTO game = gameService.createNewGame(player);
        return ResponseEntity.status(HttpStatus.CREATED).body(game);
    }

    /**
     * The end-point to receive salvo of shots from the opponent side
     * @param gameId The id of the game associated with
     * @param points The list of points on which the shots were fired
     * @return The result of shots fired whether they were missed or hit
     */
    @PostMapping("/game/{gameId}")
    public ResponseEntity<SalvoResultDTO> receiveSalvo(@PathVariable String gameId, @RequestBody List<PointDTO> points) {
        SalvoResultDTO resultDTO = salvoService.receiveSalvo(points, gameId, false);
        return ResponseEntity.status(HttpStatus.CREATED).body(resultDTO);
    }
}
