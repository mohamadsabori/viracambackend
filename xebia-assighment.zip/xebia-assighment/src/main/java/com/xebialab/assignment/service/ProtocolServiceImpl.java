package com.xebialab.assignment.service;

import com.xebialab.assignment.DTO.*;
import com.xebialab.assignment.domain.*;
import com.xebialab.assignment.enums.*;
import com.xebialab.assignment.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.IntStream;
import java.util.stream.Stream;

@Service
public class ProtocolServiceImpl implements IProtocolService {

    int count = 0;
    PlayerRepository playerRepository;
    GameRepository gameRepository;
    PointRepository pointRepository;
    SpaceshipRepository spaceshipRepository;
    IPlayerService playerService;

    private Random random;

    @Autowired
    public ProtocolServiceImpl(Random random, PlayerRepository playerRepository
            , GameRepository gameRepository
            , PointRepository pointRepository, SpaceshipRepository spaceshipRepository
            , IPlayerService playerService) {
        this.random = random;
        this.playerRepository = playerRepository;
        this.gameRepository = gameRepository;
        this.pointRepository = pointRepository;
        this.spaceshipRepository = spaceshipRepository;
        this.playerService = playerService;
    }

    @Override
    public GameDTO createNewGame(PlayerDTO opponent) {
        PlayerDTO self = new PlayerDTO("Spaceship", "xl-spaceship-player");
        opponent = new PlayerDTO(opponent.getFullName(), opponent.getUserId());
        playerService.createRandoBoardForUser(self);
        playerService.createRandoBoardForUser(opponent);
        Player selfPlayer = getPlayerEntityFromDTO(self);
        Player opponentPlayer = getPlayerEntityFromDTO(opponent);
        selfPlayer = playerRepository.save(selfPlayer);
        opponentPlayer = playerRepository.save(opponentPlayer);
        boolean b = random.nextBoolean();
        Game game = new Game().builder().gameId("match-" + getCount())
                .firstPlayer(selfPlayer)
                .secondPlayer(opponentPlayer).created(new Date())
                .starterPlayer(b ? selfPlayer : opponentPlayer)
                .build();
        game = gameRepository.save(game);
        GameDTO gameDTO = new GameDTO(self, opponent, new Date(), game.getGameId(), b ? self : opponent,b);
        return gameDTO;
    }

    private String getCount() {
        return String.valueOf(count++);
    }


    private Player getPlayerEntityFromDTO(PlayerDTO playerDTO) {
        Player player = new Player();
        List<Spaceship> spaceships = new ArrayList<>();
        for (SpaceshipDTO spaceship : playerDTO.getSpaceships()) {
            Spaceship spaceship1 = new Spaceship();
            spaceship1.setName(spaceship.getName());
            spaceship1.setStatus(spaceship.getStatus());
            List<Point> points = new ArrayList<>();
            for (SpotDTO spotDTO : spaceship.getPosition()) {
                Point point = new Point();
                point.setCol(spotDTO.getCol());
                point.setRow(spotDTO.getRow());
                point.setStatus(String.valueOf(spotDTO.getStatus()));
                pointRepository.save(point);
                points.add(point);
            }
            spaceship1.setPoints(points);
            spaceshipRepository.save(spaceship1);
            spaceships.add(spaceship1);
        }
        player.setSpaceships(spaceships);
        /*player.setBoard(new ArrayList<>(playerDTO.getBoard().length));
        for (int i = 0; i < playerDTO.getBoard().length; i++) {
            BoardInfo info = getBoardInfo(playerDTO, i);
            player.getBoard().add(info);
        }*/
        player.setFullName(playerDTO.getFullName());
        player.setUserId(playerDTO.getUserId());
        return player;
    }
}
