package com.xebialab.assignment.service;

import com.xebialab.assignment.DTO.PointDTO;
import com.xebialab.assignment.DTO.SalvoResultDTO;

import java.util.List;


/**
 * The main interface to handle business related to salvo shots.
 * This interface is references in other service classes and controllers
 * as dependencies.
 */
public interface ISalvoService {

    /**
     * Handles the fires of shots from the opponent
     * @param fireInfo The list of points that were aimed
     * @param gameId The identifier of the game associated
     * @param isSelf Determines if the shots were fired from the opponent or not
     * @return The result of the salvo of shots whether they were miss or hit
     */
    SalvoResultDTO receiveSalvo(List<PointDTO> fireInfo, String gameId, boolean isSelf);
}
