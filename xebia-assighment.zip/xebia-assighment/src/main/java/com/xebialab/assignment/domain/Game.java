package com.xebialab.assignment.domain;

import lombok.*;

import javax.persistence.*;
import java.util.Date;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
@Entity
public class Game {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id", nullable = false)
    int id;
    @ManyToOne
    private Player firstPlayer;
    @ManyToOne
    private Player secondPlayer;
    @Column(name = "created", nullable = false)
    private Date created;
    @Column(name = "gameId", nullable = false)
    private String gameId;
    @ManyToOne
    private Player starterPlayer;
}
