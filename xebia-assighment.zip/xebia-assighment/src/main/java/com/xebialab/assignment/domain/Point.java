package com.xebialab.assignment.domain;

import javax.persistence.*;

@Entity
@Table(name = "points")
public class Point {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id", nullable = false)
    private int id;

    @Column(name = "point_row", nullable = false)
    private int row;

    @Column(name = "point_col", nullable = false)
    private int col;

    @Column(name = "status", nullable = false)
    private String status;

    public Point() {
    }

    public Point(int row, int col, String status) {
        this.row = row;
        this.col = col;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getRow() {
        return row;
    }

    public void setRow(int row) {
        this.row = row;
    }

    public int getCol() {
        return col;
    }

    public void setCol(int col) {
        this.col = col;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}

