package com.xebialab.assignment.service;

import com.xebialab.assignment.DTO.PlayerDTO;

/**
 * The main interface to handle business related to players and creating random board for each player.
 * This interface is references in other service classes and controllers
 * as dependencies.
 */

public interface IPlayerService {
    void createRandoBoardForUser(PlayerDTO player);
}
