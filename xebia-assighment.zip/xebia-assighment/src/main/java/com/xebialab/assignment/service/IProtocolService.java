package com.xebialab.assignment.service;

import com.xebialab.assignment.DTO.GameDTO;
import com.xebialab.assignment.DTO.PlayerDTO;

/**
 * The main interface to handle business related to spaceships.
 * This interface is references in other service classes and controllers
 * as dependencies.
 */
public interface IProtocolService {

    /**
     * Creates a new Game with the given opponent player
     * @param user The opoonent user to play with
     * @return The game initiated by the opponent as a DTO {@link GameDTO}
     */
    GameDTO createNewGame(PlayerDTO user);

}
