package com.xebialab.assignment.DTO;

import lombok.Getter;
import lombok.Setter;
import java.util.ArrayList;
import java.util.List;


@Getter
@Setter
public class PlayerDTO {

    String fullName;
    String userId;
    private char[][] board = new char[16][16];
    List<SpaceshipDTO> spaceships = new ArrayList<>();
    public PlayerDTO() {}

    public PlayerDTO(String fullName, String userId)
    {
        this.fullName= fullName;
        this.userId = userId;
        setBoard();
    }
    private void setBoard() {
        for (int i=0; i <board.length ; i++ ) {
            for (int j  =0; j < board[i].length;j++) {
                board[i][j] = '.';
            }
        }
    }
}
