package com.xebialab.assignment.repository;

import com.xebialab.assignment.domain.Spaceship;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SpaceshipRepository extends CrudRepository<Spaceship, Integer> {
}
