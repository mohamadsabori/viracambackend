package com.xebialab.assignment.DTO;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Service;

@Getter
@AllArgsConstructor
@Setter
public class SpotDTO {
    private final int row;
    private final int col;
    private char status;
}
