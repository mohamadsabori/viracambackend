package com.xebialab.assignment.service;

import com.xebialab.assignment.DTO.PlayerDTO;
import com.xebialab.assignment.DTO.SpaceshipDTO;
import com.xebialab.assignment.DTO.SpotDTO;
import com.xebialab.assignment.enums.*;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Random;
import java.util.stream.IntStream;
import java.util.stream.Stream;

@Service
public class PlayerServiceImpl implements IPlayerService {

    Random random;

    public PlayerServiceImpl(Random random) {
        this.random = random;
    }

    /**
     * creating random board for each player
     * @param player Parameter will modify and has random board after function process finish
     */

    @Override
    public void createRandoBoardForUser(PlayerDTO player) {
        initPlayerSpaceships(player);
        createRandomBoard(player);
    }

    private void initPlayerSpaceships(PlayerDTO player) {
        player.getSpaceships().add(new Angle());
        player.getSpaceships().add(new Winger());
        player.getSpaceships().add(new AClass());
        player.getSpaceships().add(new BClass());
        player.getSpaceships().add(new SClass());
    }

    private void createRandomBoard(PlayerDTO player) {
        int col, row, rowsNeeded, colsNeeded, latestColumn;
        boolean canPlace;
        char[][] board = player.getBoard();
        for (SpaceshipDTO spaceship : player.getSpaceships()) {
            do {
                colsNeeded = getNeededColumnsCount(spaceship);
                rowsNeeded = getNeededRowsCount(spaceship);
                col = this.random.nextInt(16 - colsNeeded);
                row = this.random.nextInt(16 - rowsNeeded);

                canPlace = validateSpaceshipInsertionToBoard(board, rowsNeeded, row, colsNeeded, col);
            } while (!canPlace);
            latestColumn = col;
            insertSpaceshipAtoBoard(row, col, latestColumn, board, spaceship);
            spaceship.setStatus("Ready");
        }
    }

    private int getNeededRowsCount(SpaceshipDTO spaceship) {
        char[] charArray = spaceship.getShape().toCharArray();
        Stream<Character> chars = IntStream.range(0, charArray.length).mapToObj(i -> charArray[i]);

        return ((int) chars.filter(i -> i.equals('\n')).count()) + 1;
    }

    private int getNeededColumnsCount(SpaceshipDTO spaceship) {
        return Arrays.stream(spaceship.getShape().split("\n"))
                .max(Comparator.comparingInt(String::length))
                .map(String::length)
                .get() + 1;
    }

    private boolean validateSpaceshipInsertionToBoard(char[][] board, int rowsNeeded, int row, int colsNeeded, int col) {
        int totalRows = rowsNeeded + row;
        int totalCols = colsNeeded + col;

        boolean result = false;
        if (board[row][col] != '*')
            result = true;

        for (int i = row; (i < totalRows) && (i < board.length); i++)
            for (int j = col; (j < totalCols) && (j < board.length); j++)
                if (board[i][j] == '*') {
                    result = false;
                    break;
                }
        return result;
    }

    private void insertSpaceshipAtoBoard(int startingRow, int startingCol,
                                         int latestColumn, char[][] board, SpaceshipDTO spaceship) {
        for (char character : spaceship.getShape().toCharArray()) {

            if (character == '.')
                startingCol++;
            else if (character == '\n') {

                startingRow++;
                startingCol = latestColumn;
            } else {

                board[startingRow][startingCol] = character;
                spaceship.getPosition().add(new SpotDTO(startingRow, startingCol, character));
                startingCol++;
            }
        }
    }

}
