package com.xebialab.assignment;

import com.xebialab.assignment.domain.Player;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.Random;


@SpringBootApplication
public class XebiaLabAssessmentGameApplication {


	public static void main(String[] args) {
		SpringApplication.run(XebiaLabAssessmentGameApplication.class, args);
	}

    @Bean
    public Random random() {
	    return new Random();
    }
}
