package com.xebialab.assignment.DTO;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
public class GameDTO {
    private PlayerDTO firstPlayer;
    private PlayerDTO secondPlayer;
    private Date created;
    private String gameId;
    private PlayerDTO starterPlayer;
    private boolean isMyTurn;
}
