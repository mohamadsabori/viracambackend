package com.xebialab.assignment.service;

import com.xebialab.assignment.DTO.*;
import com.xebialab.assignment.domain.Game;
import com.xebialab.assignment.domain.Player;
import com.xebialab.assignment.domain.Point;
import com.xebialab.assignment.domain.Spaceship;
import com.xebialab.assignment.enums.*;
import com.xebialab.assignment.repository.*;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class SalvoServiceImpl implements ISalvoService {

    PlayerRepository playerRepository;
    GameRepository gameRepository;
    PointRepository pointRepository;
    SpaceshipRepository spaceshipRepository;

    public SalvoServiceImpl(PlayerRepository playerRepository
            , GameRepository gameRepository
            , PointRepository pointRepository, SpaceshipRepository spaceshipRepository){
        this.playerRepository = playerRepository;
        this.gameRepository = gameRepository;
        this.pointRepository = pointRepository;
        this.spaceshipRepository = spaceshipRepository;
    }

    @Override
    public SalvoResultDTO receiveSalvo(List<PointDTO> fireInfo, String gameId, boolean isSelf) {
        Game game = gameRepository.findOneByGameId(gameId);
        Player player = !isSelf ? game.getFirstPlayer() : game.getSecondPlayer();
        PlayerDTO playerDTO = getPlayerDTOFromEntity(player);
        for (PointDTO pointDTO : fireInfo) {
            String[] parts = pointDTO.getPoint().contains("X") ? pointDTO.getPoint().split("X") : pointDTO.getPoint().split("x");
            int row,col;
            row = extractNumbericValueFromHex(parts[0]);
            col = extractNumbericValueFromHex(parts[1]);
            Optional<SpaceshipDTO> spaceshipDTO = playerDTO.getSpaceships().stream()
                    .filter(e -> e.getPosition()
                            .stream()
                            .anyMatch(p -> p.getRow() == row && p.getCol() == col && p.getStatus() == '*')).findFirst();
            if (!spaceshipDTO.isPresent()) {
                pointDTO.setStatus("miss");
            } else {
                Optional<Spaceship> spaceship = spaceshipRepository.findById(spaceshipDTO.get().getId());
                setShotPointOnSpaceShip(row, col, spaceship.get(), playerDTO, pointDTO);
            }
        }
        //Switch to another player
        game.setStarterPlayer(game.getStarterPlayer().getId() == game.getFirstPlayer().getId() ? game.getSecondPlayer()
                : game.getFirstPlayer());
        gameRepository.save(game);
        GameDTO gameDTO = new GameDTO(getPlayerDTOFromEntity(game.getFirstPlayer())
                , getPlayerDTOFromEntity(game.getSecondPlayer()), game.getCreated()
                , game.getGameId()
                , getPlayerDTOFromEntity(game.getStarterPlayer())
                ,game.getStarterPlayer().getId() == game.getFirstPlayer().getId() ? true : false);
        return new SalvoResultDTO(fireInfo, gameDTO);
    }

    private int extractNumbericValueFromHex(String part) {
        int row;
        if(part.equals("A") || part.equals("a")){
            row = 10;
        }else if(part.equals("B") || part.equals("b")){
            row = 11;
        }else if(part.equals("C") || part.equals("c")){
            row = 12;
        }else if(part.equals("D") || part.equals("d")){
            row = 13;
        }else if(part.equals("E") || part.equals("e")){
            row = 14;
        }else if(part.equals("F") || part.equals("f")){
            row = 15;
        }else{
            row = Integer.parseInt(part);
        }
        return row;
    }

    private PlayerDTO getPlayerDTOFromEntity(Player player) {
        PlayerDTO playerDTO = new PlayerDTO(player.getFullName(), player.getUserId());
        char[][] chars = new char[16][16];
        List<SpaceshipDTO> spaceshipDTOS = new ArrayList<>();
        getSpaceshipDTO(player, playerDTO, chars);
        playerDTO.setBoard(chars);
        return playerDTO;
    }

    private void getSpaceshipDTO(Player player, PlayerDTO playerDTO, char[][] chars) {
        for (Spaceship spaceship : player.getSpaceships()) {
            SpaceshipDTO spaceshipDTO;
            spaceshipDTO = getSpaceshipDTODetails(spaceship);
            for (Point point : spaceship.getPoints()) {
                chars[point.getRow()][point.getCol()] = point.getStatus().toCharArray()[0];
                spaceshipDTO.getPosition().add(new SpotDTO(point.getRow(), point.getCol(), point.getStatus().toCharArray()[0]));
            }
            spaceshipDTO.setStatus(spaceship.getStatus());
            spaceshipDTO.setId(spaceship.getId());
            playerDTO.getSpaceships().add(spaceshipDTO);
        }
    }

    private SpaceshipDTO getSpaceshipDTODetails(Spaceship spaceship) {
        SpaceshipDTO spaceshipDTO;
        if (spaceship.getName().equals("A-CLass")) {
            spaceshipDTO = new AClass();
        } else if (spaceship.getName().equals("B-Class")) {
            spaceshipDTO = new BClass();
        } else if (spaceship.getName().equals("Angle")) {
            spaceshipDTO = new Angle();
        } else if (spaceship.getName().equals("S-Class")) {
            spaceshipDTO = new SClass();
        } else {
            //if(spaceship.getName().equals("Winger")){
            spaceshipDTO = new Winger();
        }
        return spaceshipDTO;
    }

    private void setShotPointOnSpaceShip(int row, int col, Spaceship spaceship, PlayerDTO playerDTO, PointDTO fireInfo) {
        if (spaceship.getStatus().equals("kill")) {
            fireInfo.setStatus("kill");
        } else {
            Optional<Point> point = spaceship.getPoints().stream().filter(p -> p.getRow() == row && p.getCol() == col && p.getStatus().equals("*"))
                    .findFirst();
            point.ifPresent(p -> p.setStatus("X"));
            pointRepository.save(point.get());
            playerDTO.getBoard()[row][col] = 'X';
            Spaceship spaceship1 = spaceshipRepository.findById(spaceship.getId()).get();
            String spaceshipDamageInfo = getSpaceshipDamageInfo(spaceship1, point.get());
            if(spaceshipDamageInfo.equals("DESTROYED")){
                spaceship1.setStatus("kill");
            }else{
                spaceship1.setStatus("hit");
            }
            spaceshipRepository.save(spaceship1);
            fireInfo.setStatus(spaceshipDamageInfo); ;
        }
    }

    private String getSpaceshipDamageInfo(Spaceship spaceship, Point point) {
        if (spaceship.getPoints().stream().allMatch(p -> p.getStatus().equals("X"))) {
            spaceship.setStatus("DESTROYED");
            return "kill";
        } else {
            spaceship.setStatus("HIT");
            return "hit";
        }

    }
}
