package com.xebialab.assignment.DTO;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class GameInfoDTO {
    PlayerDTO self;
    PlayerDTO opponent;
    GameDTO gameDTO;
}
