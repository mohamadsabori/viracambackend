package com.xebialab.assignment.enums;

import com.xebialab.assignment.DTO.SpaceshipDTO;

public class Winger extends SpaceshipDTO {
    public Winger() {
        super("Winger");
        setShape("*.*\n*.*\n.*.\n*.*\n*.*");
    }
}
