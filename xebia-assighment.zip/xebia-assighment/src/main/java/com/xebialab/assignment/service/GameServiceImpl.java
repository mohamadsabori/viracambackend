package com.xebialab.assignment.service;

import com.xebialab.assignment.DTO.*;
import com.xebialab.assignment.domain.Game;
import com.xebialab.assignment.domain.Player;
import com.xebialab.assignment.domain.Point;
import com.xebialab.assignment.domain.Spaceship;
import com.xebialab.assignment.enums.*;
import com.xebialab.assignment.repository.GameRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class GameServiceImpl implements IGameService {

    GameRepository gameRepository;

    GameServiceImpl(GameRepository gameRepository){
        this.gameRepository = gameRepository;
    }

    @Override
    public Optional<GameInfoDTO> getGameById(String game_id) {
        Game game = gameRepository.findOneByGameId(game_id);
        if(game == null){
            return Optional.empty();
        }
        GameDTO gameDTO = new GameDTO(getPlayerDTOFromEntity(game.getFirstPlayer())
                , getPlayerDTOFromEntity(game.getSecondPlayer()), game.getCreated()
                , game.getGameId()
                , getPlayerDTOFromEntity(game.getStarterPlayer())
                , game.getStarterPlayer().getId() == game.getFirstPlayer().getId() ? true : false);
        Optional<GameInfoDTO> gameInfoDTO = Optional.of(new GameInfoDTO(gameDTO.getFirstPlayer(), gameDTO.getSecondPlayer(), gameDTO));
        return gameInfoDTO;
    }

    private PlayerDTO getPlayerDTOFromEntity(Player player) {
        PlayerDTO playerDTO = new PlayerDTO(player.getFullName(), player.getUserId());
        char[][] chars = new char[16][16];
        List<SpaceshipDTO> spaceshipDTOS = new ArrayList<>();
        for (Spaceship spaceship : player.getSpaceships()) {
            SpaceshipDTO spaceshipDTO;
            if (spaceship.getName().equals("A-CLass")) {
                spaceshipDTO = new AClass();
            } else if (spaceship.getName().equals("B-Class")) {
                spaceshipDTO = new BClass();
            } else if (spaceship.getName().equals("Angle")) {
                spaceshipDTO = new Angle();
            } else if (spaceship.getName().equals("S-Class")) {
                spaceshipDTO = new SClass();
            } else {
                //if(spaceship.getName().equals("Winger")){
                spaceshipDTO = new Winger();
            }
            for (Point point : spaceship.getPoints()) {
                chars[point.getRow()][point.getCol()] = point.getStatus().toCharArray()[0];
                spaceshipDTO.getPosition().add(new SpotDTO(point.getRow(), point.getCol(), point.getStatus().toCharArray()[0]));
            }
            spaceshipDTO.setStatus(spaceship.getStatus());
            spaceshipDTO.setId(spaceship.getId());
            playerDTO.getSpaceships().add(spaceshipDTO);
        }
        playerDTO.setBoard(chars);
        return playerDTO;
    }

}
