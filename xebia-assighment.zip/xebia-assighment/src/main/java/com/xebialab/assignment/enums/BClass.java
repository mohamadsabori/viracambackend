package com.xebialab.assignment.enums;

import com.xebialab.assignment.DTO.SpaceshipDTO;

public class BClass extends SpaceshipDTO {
    public BClass() {
        super("B-Class");
        setShape("**.\n*.*\n**.\n*.*\n**");
    }
}
