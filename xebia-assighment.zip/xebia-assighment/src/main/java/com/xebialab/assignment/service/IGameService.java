package com.xebialab.assignment.service;

import com.xebialab.assignment.DTO.GameInfoDTO;

import java.util.Optional;

/**
 * The main interface to handle business related to a game.
 * This interface is references in other service classes and controllers
 * as dependencies.
 */
public interface IGameService {

    /**
     * Returns the game persisted with the given identifier
     * @param game_id The identifier of the game to be returned
     * @return The game associated with the identifier.
     */
    Optional<GameInfoDTO> getGameById(String game_id);
}
