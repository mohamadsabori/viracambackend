package com.xebialab.assignment.DTO;

public class PointDTO {
    String point;
    String status;

    public PointDTO() {}

    public PointDTO(String point, String status) {
        this.point = point;
        this.status = status;
    }

    public String getPoint() {
        return point;
    }

    public void setPoint(String point) {
        this.point = point;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
