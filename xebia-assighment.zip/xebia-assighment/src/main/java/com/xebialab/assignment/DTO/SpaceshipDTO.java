package com.xebialab.assignment.DTO;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public abstract class SpaceshipDTO implements Serializable {
    private String name;
    private String shape;
    private List<SpotDTO> position = new ArrayList<>();
    private String status;
    private int id;


    public SpaceshipDTO(String name, String shape, List<SpotDTO> position, String status, int id) {
        this.name = name;
        this.shape = shape;
        this.position = position;
        this.status = status;
        this.id = id;
    }

    public SpaceshipDTO(String name) {
        this.name = name;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getShape() {
        return shape;
    }

    public void setShape(String shape) {
        this.shape = shape;
    }

    public List<SpotDTO> getPosition() {
        return position;
    }

    public void setPosition(List<SpotDTO> position) {
        this.position = position;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
