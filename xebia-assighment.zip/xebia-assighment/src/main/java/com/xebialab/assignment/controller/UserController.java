package com.xebialab.assignment.controller;

import com.xebialab.assignment.DTO.GameInfoDTO;
import com.xebialab.assignment.DTO.PointDTO;
import com.xebialab.assignment.DTO.SalvoResultDTO;
import com.xebialab.assignment.service.IGameService;
import com.xebialab.assignment.service.ISalvoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

/**
 * User Handler Class
 * Handles related to User communication including receiving the current game status associated with user
 */
@RestController
@RequestMapping("/user")
public class UserController implements Serializable {

    IGameService gameService;
    ISalvoService salvoService;

    UserController(IGameService gameService,ISalvoService salvoService){
        this.gameService = gameService;
        this.salvoService = salvoService;
    }

    /**
     * Gets the current game associated with the user playing the game
     * @implNote Does not show opponent's board
     * @param game_id The identifier of the game to be views
     * @return The current ongoing game
     */
    @GetMapping("/game/{game_id}")
    public ResponseEntity<GameInfoDTO> getGameById(@PathVariable String game_id) {
        Optional<GameInfoDTO> game = gameService.getGameById(game_id);
        game.orElseThrow(() -> new RuntimeException("No game found!"));
        return ResponseEntity.status(HttpStatus.OK).body(game.get());
    }

    /**
     *
     * @param game_id   The identifier of the game to shot
     * @param points
     * @return The result of game after shoting
     */
    @GetMapping("/game/{game_id}/fire")
    public ResponseEntity<SalvoResultDTO> fireSalvo(@PathVariable String game_id,@RequestBody List<PointDTO> points) {
        SalvoResultDTO resultDTO = salvoService.receiveSalvo(points, game_id, true);
        return ResponseEntity.status(HttpStatus.CREATED).body(resultDTO);
    }
}
