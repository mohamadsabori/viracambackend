package com.xebialab.assignment.domain;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@Entity
public class Player {
    @Column(name = "fullName", nullable = false)
    String fullName;
    @Column(name = "userId", nullable = false)
    String userId;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id", nullable = false)
    int id;
    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name="player_id")
    List<Spaceship> spaceships = new ArrayList<>();
    public Player() {}

    public Player(String fullName, String userId)
    {
        this.fullName= fullName;
        this.userId = userId;
    }
}
