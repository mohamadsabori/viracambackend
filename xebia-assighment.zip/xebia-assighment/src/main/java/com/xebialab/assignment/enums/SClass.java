package com.xebialab.assignment.enums;

import com.xebialab.assignment.DTO.SpaceshipDTO;

public class SClass extends SpaceshipDTO {
    public SClass() {

        super("S-Class");
        setShape(".**\n*..\n.**\n...*\n.**");
    }
}
