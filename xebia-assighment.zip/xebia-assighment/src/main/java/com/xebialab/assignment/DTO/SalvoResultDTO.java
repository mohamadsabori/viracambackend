package com.xebialab.assignment.DTO;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Getter
@Setter
@AllArgsConstructor
public class SalvoResultDTO {
    List<PointDTO> fireInfoes = new ArrayList<>();
    GameDTO gameDTO;
}
