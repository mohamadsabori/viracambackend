package com.xebialab.assignment.enums;

import com.xebialab.assignment.DTO.SpaceshipDTO;

public class Angle extends SpaceshipDTO {
    public Angle() {
        super("Angle");
        setShape("*..\n*..\n*..\n***");
    }
}
