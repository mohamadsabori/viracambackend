{\rtf1\ansi\ansicpg1252\deff0{\fonttbl{\f0\fswiss\fcharset0 Helvetica;}}
{\colortbl ;\red0\green0\blue255;}
{\*\generator Msftedit 5.41.21.2510;}\viewkind4\uc1\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\lang9\b\f0\fs40 Technologies and Logic\b0\par
\fs26\par
\fs36 The solution is written in Java and uses Spring Boot.\par
Maven is used to handle the build and dependencies of the project.\par
When the game is initiated, each player\rquote s board is initialized with its predefined spaceship instances randomly placed on the grid and the simulation is used in the user\rquote s session.\par
Each user depending on the player turn which is chosen randomly at first, can fire a salvo of shots on the opponent\rquote s grid and the result of each shot and the game status is returned as the response.\par
The grid is a 2D array indexing from 0 to 15. When the shots are fired, each HexaDecimal value is converted to its decimal format and then is evaluated for potential hit.\par
Lombok dependency is used in the project. So for builing in the IDE it may be required to enable Annotation Processing.\par
The User Interface is written in Agular JS with API calls to the end-points in the backend to initiate and play the game.\par
\b\fs40\par
Building source files\b0\fs36\par
Solution source files are placed in the root folder of the assignment including both Server and UI. To build the source files simply run the build.sh (You may need to set Environment Vriables to be able to execute build.sh.\par
\par
\b\fs40 Running the application\b0\fs36\par
The application runs on the embedded tomcat of Spring Boot application and will be available on the {\field{\*\fldinst{HYPERLINK "http://localhost:8080/xl-spaceship"}}{\fldrslt{\ul\cf1 http://localhost:8080/xl-spaceship}}}\f0\fs36  once run.sh file is executed.\par
The main page of the application will be available on {\field{\*\fldinst{HYPERLINK "http://localhost:8080/xl-spaceship"}}{\fldrslt{\ul\cf1 http://localhost:8080/xl-spaceship}}}\f0\fs36  and by clicking on the New Game it initiates the game and the board is shown afterward.\par
Playing and testing using Postman also is available and the format of JSONs sent to server are exactly the ones who are mentioned in the assignment Document.\par
\b\fs40 Testing the application\b0\fs36\par
The application has different type of tests to make sure that every end points or units work and create currect result. Test uses Spring boot runner and JUNIT and Mokito.\par
\tab\tab\tab\tab\tab\tab\tab\tab\tab Authored By:\par
\tab\tab\tab\tab\tab\tab\tab Mohamad Sabori\fs26\par
}
 